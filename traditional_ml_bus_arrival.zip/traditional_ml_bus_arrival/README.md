# Bus Arrival Time Prediction System Using Traditional Machine Learning

This project implements an end-to-end forecasting tool that compares classical regression algorithms (Linear Regression, Decision Tree, Random Forest, SVR, and XGBoost) to select the best predictor layout.

## Project Structure
*   `frontend/`: Flask web application routes, static stylesheet assets, and HTML templates.
*   `backend/`:
    *   `preprocessing/`: Handles cleaning, label mapping, and MinMaxScaler conversions.
    *   `models/`: Training script (`train.py`), evaluation reports (`evaluate.py`), and documentation generators (`generate_docs.py`).
    *   `saved_models/`: Stores serializations like `best_model.pkl`.
    *   `evaluation/`: Compares MAE, RMSE, and saves actual vs predicted, residuals, and error distribution charts.
*   `database/`: SQLite database configurations (`users.db` and `predictions.db`).
*   `docs/`: Slides presentation (`PPT.pptx`), comprehensive system report (`Project_Report.pdf`), and flow chart layout (`Architecture.png`).

## Getting Started

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Run tests to confirm registration and predictions database transactions work flawlessly:
   ```bash
   python integration_test.py
   ```

3. Launch Flask server:
   ```bash
   python frontend/app/app.py
   ```
   Open **http://127.0.0.1:5000** in your browser.
