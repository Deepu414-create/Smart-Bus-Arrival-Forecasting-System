import os
import pickle
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from xgboost import XGBRegressor

from sklearn.metrics import mean_absolute_error, r2_score

from backend.preprocessing.preprocessing import run_preprocessing_pipeline

# Set seeds
np.random.seed(42)

def generate_synthetic_data(filepath, n_samples=2500):
    """
    Generates a realistic synthetic transit dataset matching the 17 manual inputs.
    """
    print("Generating traditional ML synthetic bus dataset...")
    
    routes = ['Route_1', 'Route_2', 'Route_3', 'Route_4', 'Route_5']
    stops = {
        'Route_1': ['Stop_101', 'Stop_102', 'Stop_103', 'Stop_104', 'Stop_105'],
        'Route_2': ['Stop_201', 'Stop_202', 'Stop_203', 'Stop_204', 'Stop_205'],
        'Route_3': ['Stop_301', 'Stop_302', 'Stop_303', 'Stop_304', 'Stop_305'],
        'Route_4': ['Stop_401', 'Stop_402', 'Stop_403', 'Stop_404', 'Stop_405'],
        'Route_5': ['Stop_501', 'Stop_502', 'Stop_503', 'Stop_504', 'Stop_505'],
    }
    
    stop_gps = {}
    center_lat, center_lon = 40.7128, -74.0060
    for r_idx, r in enumerate(routes):
        for s_idx, s in enumerate(stops[r]):
            lat = center_lat + 0.01 * (r_idx - 2) + 0.002 * s_idx
            lon = center_lon + 0.01 * (r_idx - 2) + 0.002 * s_idx
            stop_gps[s] = (lat, lon)
            
    weathers = ['Sunny', 'Cloudy', 'Rainy', 'Stormy', 'Foggy']
    weather_probs = [0.45, 0.25, 0.15, 0.05, 0.10]
    
    traffics = ['Low', 'Medium', 'High']
    traffic_probs = [0.40, 0.45, 0.15]
    
    roads = ['Normal', 'Moderate', 'Heavy Traffic']
    road_probs = [0.50, 0.35, 0.15]
    
    time_blocks = ['Early Morning', 'Morning Peak', 'Afternoon', 'Evening Peak', 'Night']
    
    data_list = []
    base_time = pd.Timestamp('2026-06-20 00:00:00')
    
    for i in range(n_samples):
        route = np.random.choice(routes)
        stop = np.random.choice(stops[route])
        lat, lon = stop_gps[stop]
        
        # Pick timestamp
        hour_offset = np.random.randint(0, 30 * 24)
        timestamp = base_time + pd.Timedelta(hours=hour_offset)
        
        hour = timestamp.hour
        minute = np.random.randint(0, 60)
        decimal_hour = hour + minute / 60.0
        
        day_type = 'Weekend' if timestamp.dayofweek >= 5 else 'Weekday'
        
        # Weather, Traffic, Road Condition
        weather = np.random.choice(weathers, p=weather_probs)
        traffic = np.random.choice(traffics, p=traffic_probs)
        road = np.random.choice(roads, p=road_probs)
        
        # Determine Time Block
        if 5.0 <= decimal_hour < 7.0:
            time_block = 'Early Morning'
        elif 7.0 <= decimal_hour < 10.0:
            time_block = 'Morning Peak'
        elif 10.0 <= decimal_hour < 16.0:
            time_block = 'Afternoon'
        elif 16.0 <= decimal_hour < 19.5:
            time_block = 'Evening Peak'
        else:
            time_block = 'Night'
            
        # Peak Hour Flag
        is_peak = 'Yes' if (time_block in ['Morning Peak', 'Evening Peak'] and day_type == 'Weekday') else 'No'
        
        # Dynamic adjustments
        if is_peak == 'Yes':
            traffic = np.random.choice(['Medium', 'High'], p=[0.30, 0.70])
            road = np.random.choice(['Moderate', 'Heavy Traffic'], p=[0.40, 0.60])
        elif day_type == 'Weekend':
            traffic = np.random.choice(['Low', 'Medium'], p=[0.70, 0.30])
            
        temperature = round(float(np.random.uniform(15.0, 35.0)), 1)
        humidity = round(float(np.random.uniform(30.0, 90.0)), 1)
        
        distance = round(float(np.random.uniform(0.5, 5.0)), 2)
        # Speed correlates with traffic density
        if traffic == 'Low':
            speed = round(float(np.random.uniform(40.0, 60.0)), 1)
        elif traffic == 'Medium':
            speed = round(float(np.random.uniform(25.0, 40.0)), 1)
        else:
            speed = round(float(np.random.uniform(10.0, 25.0)), 1)
            
        prev_delay = round(float(max(0.0, np.random.exponential(2.5))), 1)
        
        # Calculate expected delay based on features
        delay = 0.5
        
        # Weather adjustments
        if weather == 'Rainy':
            delay += 2.0
        elif weather == 'Stormy':
            delay += 7.0
        elif weather == 'Foggy':
            delay += 3.5
            
        # Traffic adjustments
        if traffic == 'Medium':
            delay += 3.0
        elif traffic == 'High':
            delay += 8.5
            
        # Road condition adjustments
        if road == 'Moderate':
            delay += 1.5
        elif road == 'Heavy Traffic':
            delay += 4.0
            
        # Peak hours
        if is_peak == 'Yes':
            delay += 5.0
            
        # Delay propagation
        delay += 0.4 * prev_delay
        
        # Speed and Distance factor
        delay += (distance * 1.5) - (speed * 0.05)
        
        # Random noise
        delay += np.random.normal(0, 1.2)
        delay = max(0.0, round(delay, 2))
        
        # Scheduled travel time (base travel duration at 30km/h average)
        scheduled_travel_time = round((distance / 30.0) * 60.0 + 3.0, 1)
        actual_travel_time = round(scheduled_travel_time + delay, 1)
        
        is_delayed = 1 if delay > 5.0 else 0
        
        data_list.append({
            'timestamp': timestamp,
            'route_id': route,
            'stop_id': stop,
            'latitude': lat,
            'longitude': lon,
            'temperature': temperature,
            'humidity': humidity,
            'weather_condition': weather,
            'traffic_density': traffic,
            'day_type': day_type,
            'time_block': time_block,
            'hour': hour,
            'minute': minute,
            'bus_speed': speed,
            'distance_to_next_stop': distance,
            'prev_stop_delay': prev_delay,
            'road_condition': road,
            'peak_hour': is_peak,
            'scheduled_travel_time': scheduled_travel_time,
            'actual_travel_time': actual_travel_time,
            'delay': delay,
            'is_delayed': is_delayed
        })
        
    df = pd.DataFrame(data_list)
    df = df.sort_values('timestamp').reset_index(drop=True)
    df.to_csv(filepath, index=False)
    print(f"Dataset generated at {filepath}. Shape: {df.shape}")
    return df

def main():
    data_dir = r"C:\Users\deepi\.gemini\antigravity\scratch\traditional_ml_bus_arrival\backend\data"
    saved_model_dir = r"C:\Users\deepi\.gemini\antigravity\scratch\traditional_ml_bus_arrival\backend\saved_models"
    
    os.makedirs(data_dir, exist_ok=True)
    os.makedirs(saved_model_dir, exist_ok=True)
    
    dataset_path = os.path.join(data_dir, 'dataset.csv')
    train_path = os.path.join(data_dir, 'train.csv')
    test_path = os.path.join(data_dir, 'test.csv')
    
    # 1. Generate Dataset
    df = generate_synthetic_data(dataset_path)
    
    # Split
    split_idx = int(len(df) * 0.8)
    train_df = df.iloc[:split_idx].copy()
    test_df = df.iloc[split_idx:].copy()
    
    train_df.to_csv(train_path, index=False)
    test_df.to_csv(test_path, index=False)
    
    # 2. Run Preprocessing Pipeline
    train_df_processed, feature_cols, encoder, scaler = run_preprocessing_pipeline(
        train_df, is_training=True
    )
    test_df_processed, _, _, _ = run_preprocessing_pipeline(
        test_df, is_training=False, encoder=encoder, scaler=scaler
    )
    
    # Save preprocessing objects
    encoder.save(os.path.join(saved_model_dir, 'label_encoder.pkl'))
    scaler.save(os.path.join(saved_model_dir, 'scaler.pkl'))
    print("Preprocessing components saved.")
    
    # Extract feature matrices and target vectors
    X_train = train_df_processed[feature_cols].values
    y_train = train_df_processed['delay'].values
    
    X_test = test_df_processed[feature_cols].values
    y_test = test_df_processed['delay'].values
    
    # Define models
    models = {
        'Linear Regression': LinearRegression(),
        'Decision Tree Regressor': DecisionTreeRegressor(random_state=42, max_depth=8),
        'Random Forest Regressor': RandomForestRegressor(random_state=42, n_estimators=100, max_depth=10),
        'Support Vector Regression (SVR)': SVR(kernel='rbf', C=10.0, epsilon=0.1),
        'XGBoost Regressor': XGBRegressor(random_state=42, n_estimators=100, max_depth=6, learning_rate=0.1)
    }
    
    fitted_models = {}
    performance = {}
    
    print("\nTraining and evaluating candidate models:")
    best_model_name = None
    best_mae = float('inf')
    
    for name, model in models.items():
        print(f"Fitting {name}...")
        model.fit(X_train, y_train)
        
        preds = model.predict(X_test)
        mae = mean_absolute_error(y_test, preds)
        r2 = r2_score(y_test, preds)
        
        performance[name] = {'mae': mae, 'r2': r2}
        fitted_models[name] = model
        
        print(f"-> MAE: {mae:.4f} | R²: {r2:.4f}")
        
        # Select best model based on lowest MAE (primary validation target)
        if mae < best_mae:
            best_mae = mae
            best_model_name = name
            
    print(f"\n*** SELECTED BEST MODEL: {best_model_name} with MAE of {best_mae:.4f}")
    
    # Save best model
    best_model = fitted_models[best_model_name]
    best_model_path = os.path.join(saved_model_dir, 'best_model.pkl')
    
    # Let's save a dictionary with model metadata, class name, and weights to support loading dynamically
    best_model_payload = {
        'model_name': best_model_name,
        'model': best_model,
        'feature_names': feature_cols
    }
    with open(best_model_path, 'wb') as f:
        pickle.dump(best_model_payload, f)
        
    print(f"Saved best model dictionary payload to {best_model_path}")
    
    # Also save individual fitted models for evaluation comparison script
    for name, model in fitted_models.items():
        filename = name.lower().replace(" ", "_").replace("(", "").replace(")", "") + ".pkl"
        with open(os.path.join(saved_model_dir, filename), 'wb') as f:
            pickle.dump(model, f)
            
    print("All individual candidate models saved.")

if __name__ == '__main__':
    main()
