import os
import pickle
import numpy as np
import pandas as pd

from backend.preprocessing.preprocessing import run_preprocessing_pipeline

class TransitPredictor:
    """
    Exposes inference API for Flask web application to make real-time predictions.
    Uses the best selected traditional machine learning model.
    """
    def __init__(self, saved_model_dir=None):
        if saved_model_dir is None:
            self.saved_model_dir = r"C:\Users\deepi\.gemini\antigravity\scratch\traditional_ml_bus_arrival\backend\saved_models"
        else:
            self.saved_model_dir = saved_model_dir
            
        # Load preprocessing tools
        with open(os.path.join(self.saved_model_dir, 'label_encoder.pkl'), 'rb') as f:
            self.encoder = pickle.load(f)
        with open(os.path.join(self.saved_model_dir, 'scaler.pkl'), 'rb') as f:
            self.scaler = pickle.load(f)
        
        # Load best model payload
        with open(os.path.join(self.saved_model_dir, 'best_model.pkl'), 'rb') as f:
            payload = pickle.load(f)
            
        self.model_name = payload['model_name']
        self.model = payload['model']
        self.feature_cols = payload['feature_names']

    def predict(self, route_id, stop_id, latitude, longitude, temperature, humidity, 
                weather_condition, traffic_density, day_type, time_block, hour, minute, 
                bus_speed, distance_to_next_stop, prev_stop_delay, road_condition, peak_hour):
        """
        Runs prediction for a single request.
        """
        # Create a dictionary with current row
        current_data = {
            'route_id': route_id,
            'stop_id': stop_id,
            'latitude': float(latitude),
            'longitude': float(longitude),
            'temperature': float(temperature),
            'humidity': float(humidity),
            'weather_condition': weather_condition,
            'traffic_density': traffic_density,
            'day_type': day_type,
            'time_block': time_block,
            'hour': int(hour),
            'minute': int(minute),
            'bus_speed': float(bus_speed),
            'distance_to_next_stop': float(distance_to_next_stop),
            'prev_stop_delay': float(prev_stop_delay),
            'road_condition': road_condition,
            'peak_hour': peak_hour
        }
        
        df = pd.DataFrame([current_data])
        
        # Run preprocessing
        df_processed, _, _, _ = run_preprocessing_pipeline(
            df, is_training=False, encoder=self.encoder, scaler=self.scaler
        )
        
        X = df_processed[self.feature_cols].values
        
        # Make prediction
        predicted_delay = max(0.0, float(self.model.predict(X)[0]))
        predicted_delay = round(predicted_delay, 2)
        
        # Travel duration: (distance / 30km/h) * 60 minutes + 3 mins baseline
        scheduled_travel_time = round((float(distance_to_next_stop) / 30.0) * 60.0 + 3.0, 1)
        estimated_travel_time = round(scheduled_travel_time + predicted_delay, 1)
        
        # Calculate Estimated Bus Arrival Time (HH:MM)
        start_mins = int(hour) * 60 + int(minute)
        arrival_mins = (start_mins + int(estimated_travel_time)) % (24 * 60)
        arrival_hour = arrival_mins // 60
        arrival_minute = arrival_mins % 60
        estimated_arrival = f"{arrival_hour:02d}:{arrival_minute:02d}"
        
        # Determine status
        if predicted_delay <= 2.0:
            status = 'On Time'
        elif predicted_delay <= 7.0:
            status = 'Slight Delay'
        else:
            status = 'Heavy Delay'
            
        return {
            'expected_delay': predicted_delay,
            'estimated_travel_time': estimated_travel_time,
            'estimated_arrival': estimated_arrival,
            'status': status,
            'model_name': self.model_name
        }
