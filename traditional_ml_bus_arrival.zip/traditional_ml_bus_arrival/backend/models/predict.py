import os
import pickle
import numpy as np
import pandas as pd

from backend.preprocessing.preprocessing import run_preprocessing_pipeline

def predict_delays(df, saved_model_dir=None):
    """
    Offline/Batch prediction helper. Takes a raw DataFrame and outputs predicted delays.
    """
    if saved_model_dir is None:
        saved_model_dir = r"C:\Users\deepi\.gemini\antigravity\scratch\traditional_ml_bus_arrival\backend\saved_models"
        
    encoder = pickle.load(open(os.path.join(saved_model_dir, 'label_encoder.pkl'), 'rb'))
    scaler = pickle.load(open(os.path.join(saved_model_dir, 'scaler.pkl'), 'rb'))
    
    with open(os.path.join(saved_model_dir, 'best_model.pkl'), 'rb') as f:
        payload = pickle.load(f)
        
    best_model = payload['model']
    feature_cols = payload['feature_names']
    
    # Preprocess
    df_processed, _, _, _ = run_preprocessing_pipeline(
        df, is_training=False, encoder=encoder, scaler=scaler
    )
    
    X = df_processed[feature_cols].values
    predictions = np.maximum(0, best_model.predict(X))
    
    return predictions

if __name__ == '__main__':
    # Test if script is runnable
    print("Offline prediction script imported successfully.")
