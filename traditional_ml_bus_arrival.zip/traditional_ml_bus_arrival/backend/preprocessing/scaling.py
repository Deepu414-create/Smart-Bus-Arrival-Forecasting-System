import pickle
from sklearn.preprocessing import StandardScaler
import pandas as pd

class NumericalScaler:
    """
    Handles scaling for continuous numeric columns in spatio-temporal datasets.
    """
    def __init__(self, numeric_columns=None):
        if numeric_columns is None:
            numeric_columns = [
                'latitude', 'longitude', 'temperature', 'humidity', 
                'hour', 'minute', 'bus_speed', 'distance_to_next_stop', 
                'prev_stop_delay', 'time_of_day'
            ]
        self.numeric_columns = numeric_columns
        self.scaler = StandardScaler()
        
    def fit(self, df):
        """
        Fits StandardScaler on numeric columns.
        """
        cols_to_fit = [c for c in self.numeric_columns if c in df.columns]
        if cols_to_fit:
            self.scaler.fit(df[cols_to_fit])
        return self
        
    def transform(self, df):
        """
        Transforms numeric columns to scaled variables.
        """
        df = df.copy()
        cols_to_transform = [c for c in self.numeric_columns if c in df.columns]
        if cols_to_transform:
            df[cols_to_transform] = self.scaler.transform(df[cols_to_transform])
        return df
        
    def fit_transform(self, df):
        return self.fit(df).transform(df)
        
    def inverse_transform(self, df):
        """
        De-scales columns back to raw values.
        """
        df = df.copy()
        cols_to_inverse = [c for c in self.numeric_columns if c in df.columns]
        if cols_to_inverse:
            df[cols_to_inverse] = self.scaler.inverse_transform(df[cols_to_inverse])
        return df

    def save(self, filepath):
        with open(filepath, 'wb') as f:
            pickle.dump(self, f)

    @classmethod
    def load(cls, filepath):
        with open(filepath, 'rb') as f:
            return pickle.load(f)
