import os
import pandas as pd
import numpy as np

from backend.preprocessing.feature_engineering import build_features
from backend.preprocessing.encoding import CategoricalEncoder
from backend.preprocessing.scaling import NumericalScaler

def run_preprocessing_pipeline(df, is_training=True, encoder=None, scaler=None):
    """
    Complete modular preprocessing pipeline:
    1. Handles missing values
    2. Removes duplicates
    3. Engineered Features (decimal time of day)
    4. Categorical Encoding (Label encoder mapping)
    5. Numeric Scaling
    """
    df = df.copy()
    
    # 1. Missing Value Handling
    # Numeric cols
    num_cols = df.select_dtypes(include=[np.number]).columns
    for col in num_cols:
        df[col] = df[col].fillna(df[col].mean() if is_training else 0.0)
        
    # Categorical cols
    cat_cols = df.select_dtypes(exclude=[np.number]).columns
    for col in cat_cols:
        df[col] = df[col].fillna('Unknown')
        
    # 2. Duplicate Removal
    if is_training:
        df = df.drop_duplicates().reset_index(drop=True)
        
    # 3. Feature Engineering
    df = build_features(df)
    
    # 4. Encoding
    if is_training:
        encoder = CategoricalEncoder()
        df = encoder.fit_transform(df)
    else:
        if encoder is None:
            raise ValueError("An encoder must be provided for inference mode.")
        df = encoder.transform(df)
        
    # 5. Scaling
    if is_training:
        scaler = NumericalScaler()
        df = scaler.fit_transform(df)
    else:
        if scaler is None:
            raise ValueError("A scaler must be provided for inference mode.")
        df = scaler.transform(df)
        
    # Filter only target columns & final features list
    feature_cols = [
        'route_id', 'stop_id', 'latitude', 'longitude', 'temperature', 'humidity', 
        'weather_condition', 'traffic_density', 'day_type', 'time_block', 
        'hour', 'minute', 'bus_speed', 'distance_to_next_stop', 
        'prev_stop_delay', 'road_condition', 'peak_hour', 'time_of_day'
    ]
    
    # Keep columns that are in df
    available_features = [c for c in feature_cols if c in df.columns]
    
    return df, available_features, encoder, scaler
