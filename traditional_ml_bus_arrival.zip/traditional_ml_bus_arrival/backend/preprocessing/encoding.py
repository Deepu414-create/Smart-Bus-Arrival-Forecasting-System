import pickle
import numpy as np
import pandas as pd

class CategoricalEncoder:
    """
    Handles label encoding for categorical variables.
    Supports unseen categories gracefully by mapping them to a default index (0).
    """
    def __init__(self, categorical_columns=None):
        if categorical_columns is None:
            categorical_columns = [
                'route_id', 'stop_id', 'weather_condition', 
                'traffic_density', 'day_type', 'time_block', 
                'road_condition', 'peak_hour'
            ]
        self.categorical_columns = categorical_columns
        self.mappings = {} # column -> category -> integer
        
    def fit(self, df):
        """
        Learns dictionary mappings for each categorical column.
        """
        for col in self.categorical_columns:
            if col in df.columns:
                unique_vals = sorted(list(df[col].dropna().unique()))
                mapping = {'<unknown>': 0}
                for idx, val in enumerate(unique_vals):
                    mapping[str(val)] = idx + 1
                self.mappings[col] = mapping
        return self
        
    def transform(self, df):
        """
        Converts categories to label-encoded integers.
        """
        df = df.copy()
        for col in self.categorical_columns:
            if col in df.columns:
                mapping = self.mappings.get(col, {'<unknown>': 0})
                df[col] = df[col].astype(str).map(lambda x: mapping.get(x, 0))
        return df
        
    def fit_transform(self, df):
        return self.fit(df).transform(df)

    def save(self, filepath):
        with open(filepath, 'wb') as f:
            pickle.dump(self, f)

    @classmethod
    def load(cls, filepath):
        with open(filepath, 'rb') as f:
            return pickle.load(f)
