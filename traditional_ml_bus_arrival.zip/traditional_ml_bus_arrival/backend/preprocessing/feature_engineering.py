import numpy as np
import pandas as pd

def build_features(df):
    """
    Extracts time_of_day as a decimal hour feature from hour and minute fields.
    """
    df = df.copy()
    if 'hour' in df.columns and 'minute' in df.columns:
        df['time_of_day'] = df['hour'].astype(float) + df['minute'].astype(float) / 60.0
    else:
        df['time_of_day'] = 12.0
    return df
