-- Schema for SQLite Databases

-- ========================================================
-- SCHEMA FOR database/users.db
-- ========================================================

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    fullname TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS login_details (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    ip_address TEXT,
    user_agent TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
);


-- ========================================================
-- SCHEMA FOR database/predictions.db
-- ========================================================

CREATE TABLE IF NOT EXISTS predictions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    route_id TEXT NOT NULL,
    stop_id TEXT NOT NULL,
    latitude REAL NOT NULL,
    longitude REAL NOT NULL,
    temperature REAL NOT NULL,
    humidity REAL NOT NULL,
    weather_condition TEXT NOT NULL,
    traffic_density TEXT NOT NULL,
    day_type TEXT NOT NULL,
    time_block TEXT NOT NULL,
    hour INTEGER NOT NULL,
    minute INTEGER NOT NULL,
    bus_speed REAL NOT NULL,
    distance_to_next_stop REAL NOT NULL,
    prev_stop_delay REAL NOT NULL,
    road_condition TEXT NOT NULL,
    peak_hour TEXT NOT NULL,
    estimated_arrival TEXT NOT NULL,
    expected_delay REAL NOT NULL,
    travel_time REAL NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
