import unittest
import os
import sys

# Add project root to path
project_root = os.path.dirname(os.path.abspath(__file__))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from frontend.app.app import create_app
from frontend.app.config import Config
from frontend.app.utils import get_db_conn

class SpatioTransitIntegrationTest(unittest.TestCase):
    
    def setUp(self):
        """
        Set up the test client and configure the app for testing.
        """
        self.app = create_app()
        self.app.config['TESTING'] = True
        self.app.config['WTF_CSRF_ENABLED'] = False
        self.client = self.app.test_client()
        
        # Clean up databases from previous runs
        conn_users = get_db_conn(Config.USERS_DB)
        user = conn_users.execute("SELECT id FROM users WHERE username = ?", ('testdriver',)).fetchone()
        if user:
            user_id = user['id']
            conn_users.execute("DELETE FROM login_details WHERE user_id = ?", (user_id,))
            conn_users.execute("DELETE FROM users WHERE id = ?", (user_id,))
            conn_users.commit()
            
            conn_preds = get_db_conn(Config.PREDICTIONS_DB)
            conn_preds.execute("DELETE FROM predictions WHERE user_id = ?", (user_id,))
            conn_preds.commit()
            conn_preds.close()
        conn_users.close()
        
    def test_routing_and_auth_flow(self):
        """
        Tests the registration, login, prediction, and database logging flows.
        """
        # 1. Verify Home Page is accessible
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Bus Arrival Time Prediction System', response.data)
        
        # 2. Register a new user
        reg_data = {
            'username': 'testdriver',
            'email': 'testdriver@example.com',
            'fullname': 'Test Driver',
            'password': 'password123',
            'confirm_password': 'password123'
        }
        response = self.client.post('/register', data=reg_data, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Account registered successfully', response.data)
        
        # 3. Log in with the registered user
        login_data = {
            'username': 'testdriver',
            'password': 'password123'
        }
        response = self.client.post('/login', data=login_data, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Welcome back, Test Driver!', response.data)
        self.assertIn(b'Transit Analytics Dashboard', response.data)
        
        # 4. Perform a manual spatio-temporal bus arrival prediction (17 inputs)
        pred_data = {
            'route_id': 'Route_1',
            'stop_id': 'Stop_101',
            'latitude': '40.6928',
            'longitude': '-74.0260',
            'temperature': '24.5',
            'humidity': '60.0',
            'weather_condition': 'Sunny',
            'traffic_density': 'Medium',
            'day_type': 'Weekday',
            'time_block': 'Afternoon',
            'hour': '14',
            'minute': '30',
            'bus_speed': '35.0',
            'distance_to_next_stop': '1.0',
            'prev_stop_delay': '2.0',
            'road_condition': 'Moderate',
            'peak_hour': 'No'
        }
        response = self.client.post('/prediction', data=pred_data, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Arrival Forecast Results', response.data)
        self.assertIn(b'Expected Delay', response.data)
        
        # 5. Save the prediction permanently to the SQLite database
        response = self.client.post('/save_prediction', follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Prediction History', response.data)
        self.assertIn(b'Prediction successfully logged', response.data)
        
        # Fetch the saved prediction ID from history
        conn = get_db_conn(Config.PREDICTIONS_DB)
        pred_row = conn.execute("SELECT id FROM predictions ORDER BY timestamp DESC LIMIT 1").fetchone()
        self.assertIsNotNone(pred_row)
        pred_id = pred_row['id']
        conn.close()
        
        # 6. Submit feedback
        feedback_data = {
            'feedback': 'Integration test: traditional ML forecasting matches expectation.'
        }
        response = self.client.post(f'/feedback/{pred_id}', data=feedback_data, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Feedback saved successfully', response.data)
        
        # 7. Verify Dashboard stats
        response = self.client.get('/dashboard')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Total Prediction Logs', response.data)
        
        # 8. Log out
        response = self.client.get('/logout', follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'logged out successfully', response.data)

if __name__ == '__main__':
    unittest.main()
