import os
import sqlite3
import json
import pickle
from flask import render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash

from frontend.app.config import Config
from frontend.app.utils import get_db_conn, login_required, get_current_user

# Lazy predictor loading pattern
_predictor = None
def get_predictor():
    global _predictor
    if _predictor is None:
        from backend.models.inference import TransitPredictor
        _predictor = TransitPredictor(Config.SAVED_MODELS_DIR)
    return _predictor

def register_routes(app):
    
    @app.context_processor
    def inject_user():
        return dict(current_user=get_current_user())

    @app.route('/')
    def index():
        return render_template('index.html')

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if 'user_id' in session:
            return redirect(url_for('dashboard'))
            
        if request.method == 'POST':
            username = request.form.get('username', '').strip()
            password = request.form.get('password', '')
            
            if not username or not password:
                flash("Please fill in all fields.", 'danger')
                return render_template('login.html')
                
            conn = get_db_conn(Config.USERS_DB)
            user = conn.execute("SELECT * FROM users WHERE username = ? OR email = ?", (username, username)).fetchone()
            
            if user and check_password_hash(user['password_hash'], password):
                session['user_id'] = user['id']
                session['username'] = user['username']
                
                # Log login details
                ip_addr = request.remote_addr
                user_agent = request.headers.get('User-Agent', '')
                conn.execute(
                    "INSERT INTO login_details (user_id, ip_address, user_agent) VALUES (?, ?, ?)",
                    (user['id'], ip_addr, user_agent)
                )
                conn.commit()
                conn.close()
                
                flash(f"Welcome back, {user['fullname'] or user['username']}!", 'success')
                return redirect(url_for('dashboard'))
            else:
                conn.close()
                flash("Invalid credentials.", 'danger')
                
        return render_template('login.html')

    @app.route('/register', methods=['GET', 'POST'])
    def register():
        if 'user_id' in session:
            return redirect(url_for('dashboard'))
            
        if request.method == 'POST':
            username = request.form.get('username', '').strip()
            email = request.form.get('email', '').strip()
            fullname = request.form.get('fullname', '').strip()
            password = request.form.get('password', '')
            confirm_password = request.form.get('confirm_password', '')
            
            if not username or not email or not password or not confirm_password:
                flash("All fields are required.", 'danger')
                return render_template('register.html')
                
            if password != confirm_password:
                flash("Passwords do not match.", 'danger')
                return render_template('register.html')
                
            conn = get_db_conn(Config.USERS_DB)
            dup = conn.execute("SELECT * FROM users WHERE username = ? OR email = ?", (username, email)).fetchone()
            if dup:
                conn.close()
                flash("Username or Email is already registered.", 'danger')
                return render_template('register.html')
                
            pwd_hash = generate_password_hash(password)
            conn.execute(
                "INSERT INTO users (username, email, password_hash, fullname) VALUES (?, ?, ?, ?)",
                (username, email, pwd_hash, fullname)
            )
            conn.commit()
            conn.close()
            
            flash("Account registered successfully! Please log in.", 'success')
            return redirect(url_for('login'))
            
        return render_template('register.html')

    @app.route('/forgot-password', methods=['GET', 'POST'])
    def forgot_password():
        if request.method == 'POST':
            email = request.form.get('email', '').strip()
            new_password = request.form.get('new_password', '')
            confirm_password = request.form.get('confirm_password', '')
            
            if not email or not new_password or not confirm_password:
                flash("All fields are required.", "danger")
                return redirect(url_for('login'))
                
            if new_password != confirm_password:
                flash("Passwords do not match.", "danger")
                return redirect(url_for('login'))
                
            conn = get_db_conn(Config.USERS_DB)
            user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
            if user:
                pwd_hash = generate_password_hash(new_password)
                conn.execute("UPDATE users SET password_hash = ? WHERE id = ?", (pwd_hash, user['id']))
                conn.commit()
                conn.close()
                flash("Password updated successfully! Log in.", "success")
                return redirect(url_for('login'))
            else:
                conn.close()
                flash("Email not found.", "danger")
                
        return redirect(url_for('login'))

    @app.route('/dashboard')
    @login_required
    def dashboard():
        user_id = session['user_id']
        conn_preds = get_db_conn(Config.PREDICTIONS_DB)
        
        # Stats
        total_preds = conn_preds.execute("SELECT COUNT(*) FROM predictions WHERE user_id = ?", (user_id,)).fetchone()[0]
        
        avg_delay_row = conn_preds.execute("SELECT AVG(expected_delay) FROM predictions WHERE user_id = ?", (user_id,)).fetchone()
        avg_delay = round(avg_delay_row[0], 2) if avg_delay_row[0] is not None else 0.0
        
        # Get active model name
        best_model_name = "XGBoost Regressor"
        try:
            with open(os.path.join(Config.SAVED_MODELS_DIR, 'best_model.pkl'), 'rb') as f:
                payload = pickle.load(f)
            best_model_name = payload['model_name']
        except Exception:
            pass
        
        today_preds = conn_preds.execute(
            "SELECT COUNT(*) FROM predictions WHERE user_id = ? AND date(timestamp) = date('now')", 
            (user_id,)
        ).fetchone()[0]
        
        # Recent predictions
        recent_preds = conn_preds.execute(
            "SELECT * FROM predictions WHERE user_id = ? ORDER BY timestamp DESC LIMIT 5",
            (user_id,)
        ).fetchall()
        
        # Weather stats
        weather_stats = conn_preds.execute(
            "SELECT weather_condition, COUNT(*), AVG(expected_delay) FROM predictions WHERE user_id = ? GROUP BY weather_condition",
            (user_id,)
        ).fetchall()
        
        # Route stats
        route_stats = conn_preds.execute(
            "SELECT route_id, COUNT(*), AVG(expected_delay) FROM predictions WHERE user_id = ? GROUP BY route_id",
            (user_id,)
        ).fetchall()
        
        conn_preds.close()
        
        # Metrics comparison table
        metrics = {}
        metrics_file = os.path.join(Config.EVALUATION_DIR, 'metrics.json')
        if os.path.exists(metrics_file):
            try:
                with open(metrics_file, 'r') as f:
                    metrics = json.load(f)
            except Exception:
                pass
                
        return render_template(
            'dashboard.html',
            total_predictions=total_preds,
            avg_delay=avg_delay,
            active_model_name=best_model_name,
            today_predictions=today_preds,
            recent_predictions=recent_preds,
            weather_stats=weather_stats,
            route_stats=route_stats,
            metrics=metrics
        )

    @app.route('/prediction', methods=['GET', 'POST'])
    @login_required
    def prediction():
        if request.method == 'POST':
            try:
                # 17 manual parameters parsing
                route_id = request.form.get('route_id', '').strip()
                stop_id = request.form.get('stop_id', '').strip()
                latitude = request.form.get('latitude', '0.0').strip()
                longitude = request.form.get('longitude', '0.0').strip()
                temperature = request.form.get('temperature', '20.0').strip()
                humidity = request.form.get('humidity', '50.0').strip()
                weather_condition = request.form.get('weather_condition', '').strip()
                traffic_density = request.form.get('traffic_density', '').strip()
                day_type = request.form.get('day_type', '').strip()
                time_block = request.form.get('time_block', '').strip()
                hour = request.form.get('hour', '12').strip()
                minute = request.form.get('minute', '00').strip()
                bus_speed = request.form.get('bus_speed', '30.0').strip()
                distance_to_next_stop = request.form.get('distance_to_next_stop', '1.0').strip()
                prev_stop_delay = request.form.get('prev_stop_delay', '0.0').strip()
                road_condition = request.form.get('road_condition', '').strip()
                peak_hour = request.form.get('peak_hour', '').strip()
                
                # Predict
                predictor = get_predictor()
                out = predictor.predict(
                    route_id=route_id,
                    stop_id=stop_id,
                    latitude=latitude,
                    longitude=longitude,
                    temperature=temperature,
                    humidity=humidity,
                    weather_condition=weather_condition,
                    traffic_density=traffic_density,
                    day_type=day_type,
                    time_block=time_block,
                    hour=hour,
                    minute=minute,
                    bus_speed=bus_speed,
                    distance_to_next_stop=distance_to_next_stop,
                    prev_stop_delay=prev_stop_delay,
                    road_condition=road_condition,
                    peak_hour=peak_hour
                )
                
                # Store prediction in session temporarily
                session['last_prediction'] = {
                    'route_id': route_id,
                    'stop_id': stop_id,
                    'latitude': float(latitude),
                    'longitude': float(longitude),
                    'temperature': float(temperature),
                    'humidity': float(humidity),
                    'weather_condition': weather_condition,
                    'traffic_density': traffic_density,
                    'day_type': day_type,
                    'time_block': time_block,
                    'hour': int(hour),
                    'minute': int(minute),
                    'bus_speed': float(bus_speed),
                    'distance_to_next_stop': float(distance_to_next_stop),
                    'prev_stop_delay': float(prev_stop_delay),
                    'road_condition': road_condition,
                    'peak_hour': peak_hour,
                    'estimated_arrival': out['estimated_arrival'],
                    'expected_delay': out['expected_delay'],
                    'status': out['status'],
                    'travel_time': out['estimated_travel_time'],
                    'model_name': out['model_name']
                }
                
                flash("Model prediction completed! Please review and save.", "success")
                return redirect(url_for('result'))
                
            except Exception as e:
                flash(f"Inference error: {str(e)}. Ensure training has run.", "danger")
                return render_template('prediction.html')
                
        return render_template('prediction.html')

    @app.route('/result')
    @login_required
    def result():
        pred = session.get('last_prediction')
        if not pred:
            flash("No active prediction found. Please run a prediction first.", "warning")
            return redirect(url_for('prediction'))
            
        return render_template('result.html', pred=pred)

    @app.route('/save_prediction', methods=['POST'])
    @login_required
    def save_prediction():
        pred = session.get('last_prediction')
        if not pred:
            flash("No active prediction in session to save.", "warning")
            return redirect(url_for('prediction'))
            
        try:
            conn = get_db_conn(Config.PREDICTIONS_DB)
            conn.execute(
                """
                INSERT INTO predictions 
                (user_id, route_id, stop_id, latitude, longitude, temperature, humidity, 
                 weather_condition, traffic_density, day_type, time_block, hour, minute, 
                 bus_speed, distance_to_next_stop, prev_stop_delay, road_condition, peak_hour, 
                 estimated_arrival, expected_delay, travel_time)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    session['user_id'], pred['route_id'], pred['stop_id'], pred['latitude'], pred['longitude'],
                    pred['temperature'], pred['humidity'], pred['weather_condition'], pred['traffic_density'],
                    pred['day_type'], pred['time_block'], pred['hour'], pred['minute'], pred['bus_speed'],
                    pred['distance_to_next_stop'], pred['prev_stop_delay'], pred['road_condition'], pred['peak_hour'],
                    pred['estimated_arrival'], pred['expected_delay'], pred['travel_time']
                )
            )
            conn.commit()
            conn.close()
            
            # Clear session cache
            session.pop('last_prediction', None)
            
            flash("Prediction successfully logged in database history!", "success")
            return redirect(url_for('history'))
        except Exception as e:
            flash(f"Database error: {str(e)}", "danger")
            return redirect(url_for('result'))

    @app.route('/history')
    @login_required
    def history():
        user_id = session['user_id']
        conn = get_db_conn(Config.PREDICTIONS_DB)
        logs = conn.execute(
            "SELECT * FROM predictions WHERE user_id = ? ORDER BY timestamp DESC",
            (user_id,)
        ).fetchall()
        conn.close()
        return render_template('history.html', logs=logs)

    @app.route('/feedback/<int:prediction_id>', methods=['POST'])
    @login_required
    def feedback(prediction_id):
        user_id = session['user_id']
        feedback_text = request.form.get('feedback', '').strip()
        
        if not feedback_text:
            flash("Feedback cannot be blank.", "warning")
            return redirect(url_for('history'))
            
        conn = get_db_conn(Config.PREDICTIONS_DB)
        conn.execute(
            "UPDATE predictions SET feedback = ? WHERE id = ? AND user_id = ?",
            (feedback_text, prediction_id, user_id)
        )
        conn.commit()
        conn.close()
        
        flash("Feedback saved successfully!", "success")
        return redirect(url_for('history'))

    @app.route('/analytics')
    @login_required
    def analytics():
        conn = get_db_conn(Config.PREDICTIONS_DB)
        user_id = session['user_id']
        
        history_rows = conn.execute(
            "SELECT * FROM predictions WHERE user_id = ? ORDER BY timestamp ASC",
            (user_id,)
        ).fetchall()
        
        route_delays = conn.execute(
            "SELECT route_id, AVG(expected_delay), COUNT(*) FROM predictions WHERE user_id = ? GROUP BY route_id",
            (user_id,)
        ).fetchall()
        
        weather_delays = conn.execute(
            "SELECT weather_condition, AVG(expected_delay) FROM predictions WHERE user_id = ? GROUP BY weather_condition",
            (user_id,)
        ).fetchall()
        
        traffic_delays = conn.execute(
            "SELECT traffic_density, AVG(expected_delay) FROM predictions WHERE user_id = ? GROUP BY traffic_density",
            (user_id,)
        ).fetchall()
        
        conn.close()
        
        return render_template(
            'analytics.html',
            history=history_rows,
            route_delays=route_delays,
            weather_delays=weather_delays,
            traffic_delays=traffic_delays
        )

    @app.route('/profile', methods=['GET', 'POST'])
    @login_required
    def profile():
        user_id = session['user_id']
        conn_users = get_db_conn(Config.USERS_DB)
        
        if request.method == 'POST':
            fullname = request.form.get('fullname', '').strip()
            email = request.form.get('email', '').strip()
            
            if not fullname or not email:
                flash("All fields are required.", "danger")
            else:
                conn_users.execute(
                    "UPDATE users SET fullname = ?, email = ? WHERE id = ?",
                    (fullname, email, user_id)
                )
                conn_users.commit()
                flash("Profile updated successfully!", "success")
                
        user = conn_users.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        
        conn_preds = get_db_conn(Config.PREDICTIONS_DB)
        total_preds = conn_preds.execute("SELECT COUNT(*) FROM predictions WHERE user_id = ?", (user_id,)).fetchone()[0]
        
        logins = conn_users.execute(
            "SELECT * FROM login_details WHERE user_id = ? ORDER BY timestamp DESC LIMIT 5",
            (user_id,)
        ).fetchall()
        
        conn_users.close()
        conn_preds.close()
        
        return render_template('profile.html', user=user, total_predictions=total_preds, logins=logins)

    @app.route('/about')
    def about():
        return render_template('about.html')

    @app.route('/logout')
    def logout():
        session.clear()
        flash("You have logged out successfully.", "success")
        return redirect(url_for('index'))
