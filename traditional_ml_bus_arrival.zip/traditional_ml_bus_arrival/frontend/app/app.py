import os
import sys

# Add project root to path
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from flask import Flask
from frontend.app.config import Config
from frontend.app.utils import init_databases
from frontend.app.routes import register_routes

def create_app():
    app = Flask(
        __name__,
        template_folder=os.path.join(Config.BASE_DIR, 'frontend', 'templates'),
        static_folder=os.path.join(Config.BASE_DIR, 'frontend', 'static')
    )
    
    app.config.from_object(Config)
    
    # Initialize databases on app startup
    init_databases()
    
    # Register routes
    register_routes(app)
    
    return app

if __name__ == '__main__':
    app = create_app()
    print("Flask Server running on http://127.0.0.1:5000")
    app.run(host='127.0.0.1', port=5000, debug=True)
