import os
import sqlite3
from flask import session, redirect, url_for, g
from functools import wraps
from frontend.app.config import Config

def get_db_conn(db_path):
    """
    Creates and returns a connection to SQLite database.
    """
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def init_databases():
    """
    Executes database creation tables based on schema.sql.
    """
    os.makedirs(os.path.dirname(Config.USERS_DB), exist_ok=True)
    
    # 1. Users DB
    conn_users = get_db_conn(Config.USERS_DB)
    cursor = conn_users.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        fullname TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS login_details (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        ip_address TEXT,
        user_agent TEXT,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
    """)
    conn_users.commit()
    conn_users.close()
    
    # 2. Predictions DB
    conn_preds = get_db_conn(Config.PREDICTIONS_DB)
    cursor = conn_preds.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS predictions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        route_id TEXT NOT NULL,
        stop_id TEXT NOT NULL,
        latitude REAL NOT NULL,
        longitude REAL NOT NULL,
        temperature REAL NOT NULL,
        humidity REAL NOT NULL,
        weather_condition TEXT NOT NULL,
        traffic_density TEXT NOT NULL,
        day_type TEXT NOT NULL,
        time_block TEXT NOT NULL,
        hour INTEGER NOT NULL,
        minute INTEGER NOT NULL,
        bus_speed REAL NOT NULL,
        distance_to_next_stop REAL NOT NULL,
        prev_stop_delay REAL NOT NULL,
        road_condition TEXT NOT NULL,
        peak_hour TEXT NOT NULL,
        estimated_arrival TEXT NOT NULL,
        expected_delay REAL NOT NULL,
        travel_time REAL NOT NULL,
        feedback TEXT DEFAULT NULL,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)
    conn_preds.commit()
    conn_preds.close()
    print("Databases initialized successfully.")

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def get_current_user():
    """
    Fetches details of the currently logged-in user.
    """
    if 'user_id' not in session:
        return None
    try:
        conn = get_db_conn(Config.USERS_DB)
        user = conn.execute("SELECT * FROM users WHERE id = ?", (session['user_id'],)).fetchone()
        conn.close()
        return user
    except Exception:
        return None
