import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'transit_traditional_ml_secret_key_9981')
    
    # Project paths
    BASE_DIR = r"C:\Users\deepi\.gemini\antigravity\scratch\traditional_ml_bus_arrival"
    
    USERS_DB = os.path.join(BASE_DIR, 'database', 'users.db')
    PREDICTIONS_DB = os.path.join(BASE_DIR, 'database', 'predictions.db')
    
    SAVED_MODELS_DIR = os.path.join(BASE_DIR, 'backend', 'saved_models')
    EVALUATION_DIR = os.path.join(BASE_DIR, 'backend', 'evaluation')
